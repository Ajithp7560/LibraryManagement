const Router= require('express');
const controller = require("../controller/book_controller.js")
const router=Router();
const {Authentication}=require("../middleware/auth.js")
router.get('/',[Authentication.verifytoken],controller.getAllbooks);
router.get('/id/:book_id',[Authentication.verifytoken],controller.getbookbyid);
router.post('/',[Authentication.verifytoken],controller.addbooks);
router.delete('/:book_id',[Authentication.verifytoken],controller.deleteBookbyId);  
router.put('/id/:book_id',[Authentication.verifytoken],controller.updateBookdetails);    
module.exports = router;



