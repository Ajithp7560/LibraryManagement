const express = require('express');
const queries = require('../queries/queries.js');
const db = require("../dbconfig")
const app = express();
const routes = require('../routes/user_routes');
const bodyParser = require('body-parser');

const {
    genSaltSync,
    hashSync,
    compareSync
} = require("bcryptjs");
const jwt = require("jsonwebtoken");




const userSignUp = (req, res) => {
  
    console.log("Entered Routes Callback");

    const salt = genSaltSync(2);
  
    req.body.password = hashSync(req.body.password, salt);

    let fname = req.body.firstName;
    let lname = req.body.lastName;
    let gender = req.body.gender;
    let email = req.body.email;
    let password = req.body.password;
    let phone = req.body.phone_number;
    const headers=req.headers.inapp;
  
    if(headers!='Ajith-Machine test'){
        res.send({message:"Please Provide the valid headers"});
    }

    else{


    db.query(queries.signUp, [fname, lname, gender, email, password, phone], (error, result) => {
        if (error) {
            console.log(error);
        } else {


            res.send("Signed Up Successfully");
        }
    });
    }
}

const userSignIn = (req, res) => {

    let {
        email,
        password
    } = req.body;


    if (!email || !password) {
        return res.status(422).send(" PLz fill data properly")
    }
    const headers=req.headers.inapp;
  
    if(headers!='Ajith-Machine test'){
        res.send({message:"Please Provide the valid headers"});
    }
    else{
    db.query(queries.signIn, [email], (error, result) => {
        if (!result.rows.length) {
            res.send("User not registered");
        } else {
     
           

            let resp = {
                id: email,
                password: password

            };

 var verifypassword=compareSync(password,result.rows[0]['password']);

if(verifypassword){
            let token = jwt.sign(resp, "secret", {expiresIn: 86400});
              res.send({auth:true,token:token,Message:"User Successfully Signed in"});
}
else{
    res.send({Message:"Incorrect Password"}); 
}
          
        }
    });
    }
}

const userUpdate = (req, res) => {
    let fname = req.body.firstName;
    let lname = req.body.lastName;
    let email = req.body.email;
    let password = req.body.password;
    let phone = req.body.phone_number;

    var id = 0;
    //Get ID of user which needs to be updated
    db.query("SELECT user_id FROM \"User\" WHERE email=" + "'" + email + "'" + ";", (error, result) => {
        if (error) {
            res.send("Sign up first!");
        } else {
            id = result.rows.user_id; //Store that id in API 
        }
    })

    db.query(queries.update, [fname, lname, email, password, phone, id], (error, result) => { //Use that ID to update the user
        if (error) {
            console.log(error);
        } else {
            res.send("Data updated Successfully");
        }
    });

}

module.exports = {
    userSignUp,
    userSignIn,
    userUpdate
};