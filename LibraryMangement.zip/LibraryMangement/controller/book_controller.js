
const pool = require('../dbconfig.js');
const query = require('../queries/queries.js');



const getAllbooks = (req, res) => {
    const headers=req.headers.inapp;
  
    if(headers!='Ajith-Machine test'){
        res.send({message:"Please Provide the valid headers"});
    }
    else{
    pool.query(query.getAllbooks, (error, results) => {
        if (error) { 
            console.log(error);
        }
        else{
            res.status(200).json(results.rows);
        }
     
    })
}
}
const getbookbyid = (req, res) => {
    console.log("Inside the route");
    const book_id = parseInt(req.params.book_id);

    const headers=req.headers.inapp;
    if(headers!='Ajith-Machine test'){
        res.send({message:"Please Provide the valid headers"});
    }
    else{
    pool.query(query.getbookbyid,[book_id], (error, results) => {
        if (!results.rows.length) {
            res.send({message:"Book does not exist"});
        } else {
            console.log(results);
            res.send(results.rows);
        }

    })
}
}

const addbooks = (req, res) => {

    // const {
    //     book_name,
    //     book_author,
    //     book_description
    // } = req.body;
    let book_name=req.body.book_name;
    let book_author=req.body.book_author;
    let book_description=req.body.book_description;
    let user_id=req.body.user_id;
    const headers=req.headers.inapp;
    if(headers!='Ajith-Machine test'){
        res.send({message:"Please Provide the valid headers"});
    }
else{
    pool.query(query.checkbookexist, [book_name], (error, results) => {
        if (results.rows.length) {
        
            res.send({message:"Book with same name already exists"})
        } else {
      
            pool.query(query.addbooks, [book_name,book_author,book_description,user_id], (error, results) => {
                if (error) { 
                    console.log(error);
                }
                else{
                    res.send({message:"Book details inserted successfully"});
                }
         

           
            })
        }
    });
}
}
const deleteBookbyId = (req, res) => {
    const book_id = parseInt(req.params.book_id);
    const headers=req.headers.inapp;
    if(headers!='Ajith-Machine test'){
        res.send({message:"Please Provide the valid headers"});
    }
    
else{
    pool.query(query.getbookbyid, [book_id], (error, results) => {
        if (!results.rows.length) {
            res.send({message:"Book Does not exist"});
        } else {
            pool.query(query.deleteBookbyId, [book_id], (error, results) => {
                if (error) { 
                    console.log(error);
                }
                else{
                    res.send({message:"Books deleted  successfully"});
                }
     
            })
        }
    });
}
}
const updateBookdetails = (req, res) => {

    const book_id = parseInt(req.params.book_id);
    let book_name=req.body.book_name;
    let book_author=req.body.book_author;
    let book_description=req.body.book_description;
    let user_id=req.body.user_id;
    const headers=req.headers.inapp;
    if(headers!='Ajith-Machine test'){
        res.send({message:"Please Provide the valid headers"});
    }
    else{
    pool.query(query.getbookbyid, [book_id ], (error, results) => {
        if (!results.rows.length) {
            res.send({message:"Book  Does not exist"})
        } else {
            pool.query(query.updateBookdetails, [book_name,book_author,book_description,user_id,book_id], (error, results) => {
                if (error) { 
                    console.log(error);
                }
                else{
                    res.send({message:"Book details Updated  successfully"});
                }
              
            })
        }
    });
    }
}

module.exports = {
    getAllbooks,
    getbookbyid,
    updateBookdetails,
    deleteBookbyId,
    addbooks

};