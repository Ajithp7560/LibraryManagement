const express = require("express");
const app = express();
const port = 5600;
const dotenv = require("dotenv");

const {
    pool
} = require("./dbconfig");
const {
    json
} = require("express");


const userrRoutes = require("./routes/user_routes.js")
const bookRoutes = require("./routes/book_routes.js")

console.log('sas')

// require("dotenv").config({ path: './config.env'});
dotenv.config({
    path: './config.env'
});

app.use(express.urlencoded({
    extended: false
}));
app.use(express.json());

// app.use(require('./routes/userroutes.js'));

app.use("/api/v1/users", userrRoutes)
app.use("/api/v1/books",bookRoutes)




app.listen(port, () => {
    console.log(`Connection successful is at port ${port}`);
})