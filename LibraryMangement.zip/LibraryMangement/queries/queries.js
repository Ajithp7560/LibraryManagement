


// Queries for Books ==========================================================================
const getAllbooks="select * from book_details";

const getbookbyid="select * from book_details where book_id=$1;";
 const  checkbookexist="select book_name from book_details  where  book_name=$1";
const  addbooks="insert into book_details(book_name,book_author,book_description,user_id)  values($1,$2,$3,$4)";
 const deleteBookbyId ="delete from book_details where book_id=$1";
 const updateBookdetails="update book_details set book_name=$1 ,book_author=$2,book_description=$3,user_id=$4 where book_id=$5";


// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++






//Queries for user ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


const signUp = "INSERT INTO \"User\"(firstname, lastname, gender, email, password, phone_number) VALUES($1, $2, $3, $4, $5, $6);";
const signIn = "SELECT * FROM \"User\" WHERE email=$1 ;";
const update = "UPDATE \"User\" SET firstname=$1, lastname=$2, email=$3, password=$4, phone_number=$5 WHERE user_id=$6;";













module.exports={
      getAllbooks,
      getbookbyid,
      addbooks,
     checkbookexist,
     updateBookdetails,
     deleteBookbyId ,
    signUp, signIn, update,

};


    